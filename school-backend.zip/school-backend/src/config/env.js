import 'dotenv/config';

function required(name, fallback = undefined) {
  const value = process.env[name] ?? fallback;
  if (value === undefined || value === '') throw new Error(`Missing environment variable: ${name}`);
  return value;
}

export const env = {
  port: Number(process.env.PORT || 5000),
  nodeEnv: process.env.NODE_ENV || 'development',
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
  db: {
    host: required('DB_HOST', 'localhost'),
    port: Number(process.env.DB_PORT || 5432),
    name: required('DB_NAME', 'school_management'),
    user: required('DB_USER', 'postgres'),
    password: process.env.DB_PASSWORD || ''
  },
  jwtSecret: required('JWT_SECRET'),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  admin: {
    name: required('ADMIN_NAME', 'Codeshape'),
    email: required('ADMIN_EMAIL'),
    password: required('ADMIN_PASSWORD')
  }
};
